import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { parseHtml, cleanTitle, slugTitle, pickOffers, affiliateUrl, isPrivateIp, storeName, relevance } from './lib.js';

let n = 0;
const t = (name, fn) => Promise.resolve().then(fn).then(() => { n++; console.log('ok  ', name); }, e => { console.error('FAIL', name, '\n', e); process.exitCode = 1; });

await t('parseHtml: JSON-LD Product', () => {
  const html = `<html><head><title>x</title><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"Product","name":"Apple iPhone 15 (128 GB) - Black","offers":{"@type":"Offer","price":"64,999","priceCurrency":"INR"}}]}</script></head></html>`;
  assert.deepEqual(parseHtml(html), { title: 'Apple iPhone 15 (128 GB) - Black', price: 64999 });
});
await t('parseHtml: og:title fallback, non-INR ignored', () => {
  const html = `<meta content="boAt Airdopes 141 &amp; more" property="og:title"><script type="application/ld+json">{"@type":"Product","name":"X","offers":{"price":10,"priceCurrency":"USD"}}</script>`;
  const r = parseHtml(html);
  assert.equal(r.price, null);
  assert.equal(r.title, 'X');
  assert.equal(parseHtml('<meta content="boAt &amp; Co" property="og:title">').title, 'boAt & Co');
});
await t('cleanTitle', () => {
  assert.equal(cleanTitle('Amazon.in: Buy Apple iPhone 15 (128 GB) - Black : Electronics'), 'Apple iPhone 15 (128 GB) - Black');
  assert.equal(cleanTitle('Apple iPhone 15 (Black, 128 GB) | Flipkart.com'), 'Apple iPhone 15 (Black, 128 GB)');
  assert.equal(cleanTitle('Buy Samsung 43 inch TV online at best price in India'), 'Samsung 43 inch TV');
});
await t('slugTitle', () => {
  assert.equal(slugTitle('https://www.amazon.in/Apple-iPhone-15-128-GB/dp/B0CHX1W1XY?ref=x'), 'Apple iPhone 15 128 GB');
  assert.equal(slugTitle('https://www.flipkart.com/apple-iphone-15-black-128-gb/p/itm6ac6485515ae4'), 'apple iphone 15 black 128 gb');
  assert.equal(slugTitle('https://example.com/search?q=boat+airdopes'), 'boat airdopes');
});
await t('storeName', () => {
  assert.equal(storeName('www.amazon.in'), 'Amazon.in');
  assert.equal(storeName('Reliance Digital'), 'Reliance Digital');
  assert.equal(storeName('www.shop.example.com'), 'shop.example');
});
await t('pickOffers: accessory aur galat product hatao, store ka min rakho', () => {
  const q = 'Apple iPhone 15 128 GB Black';
  const items = [
    { store: 'Amazon.in', title: 'Apple iPhone 15 (128 GB) - Black', price: 65490, url: 'https://a' },
    { store: 'Amazon.in', title: 'Apple iPhone 15 128 GB Black', price: 64990, url: 'https://a2' },
    { store: 'Flipkart', title: 'Apple iPhone 15 128 GB Black', price: 64999, url: 'https://f' },
    { store: 'Croma', title: 'Apple iPhone 15 Back Cover Case 128 GB Black', price: 499, url: 'https://c' },
    { store: 'Reliance Digital', title: 'Apple iPhone 15 Pro Max 256 GB Titanium', price: 159900, url: 'https://r' },
    { store: 'Vijay Sales', title: 'Apple iPhone 15 128GB Black', price: 66000, url: 'https://v' }
  ];
  const r = pickOffers(q, items);
  assert.deepEqual(r.map(x => x.store), ['Amazon.in', 'Flipkart', 'Vijay Sales']);
  assert.equal(r[0].price, 64990);
});
await t('affiliateUrl', () => {
  const cfg = { amazonTag: 'me-21', flipkartId: 'fk1', rules: { 'croma.com': { param: 'affid', value: 'c9' }, 'myntra.com': { template: 'https://trk.example/?u={url}' } } };
  assert.match(affiliateUrl('https://www.amazon.in/dp/B0?tag=old', cfg), /tag=me-21/);
  assert.match(affiliateUrl('https://www.flipkart.com/x/p/itm1', cfg), /affid=fk1/);
  assert.match(affiliateUrl('https://www.croma.com/p/1', cfg), /affid=c9/);
  assert.equal(affiliateUrl('https://www.myntra.com/a', cfg), 'https://trk.example/?u=https%3A%2F%2Fwww.myntra.com%2Fa');
  assert.equal(affiliateUrl('https://other.com/a', cfg), 'https://other.com/a');
});
await t('isPrivateIp', () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.0.5', '172.20.0.1', '169.254.169.254', '::1', 'fd00::1', '::ffff:127.0.0.1']) assert.ok(isPrivateIp(ip), ip);
  for (const ip of ['8.8.8.8', '13.107.42.14', '2606:4700::1111']) assert.ok(!isPrivateIp(ip), ip);
});

// ---- server integration (demo mode, temp database) ----
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dd-'));
process.env.DB_PATH = path.join(tmp, 't.db');
process.env.SERPAPI_KEY = '';
process.env.AFFILIATE_AMAZON_TAG = 'test-21';
const { server } = await import('./server.js');
await new Promise(r => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;
const post = (input) => fetch(base + '/api/lookup', { method: 'POST', body: JSON.stringify({ input }) });

await t('API: naam se lookup', async () => {
  const r = await post('Apple iPhone 15 128 GB');
  assert.equal(r.status, 200);
  const d = await r.json();
  assert.ok(d.offers.length >= 4);
  assert.ok(d.offers[0].price <= d.offers[1].price);
  assert.ok(Object.values(d.history).every(h => h.length > 30));
  assert.ok(d.allTimeLow.price <= d.offers[0].price);
});
await t('API: link se lookup (network band, link ke naam se chale)', async () => {
  const r = await post('https://www.amazon.in/Apple-iPhone-15-128-GB/dp/B0CHX1W1XY');
  assert.equal(r.status, 200);
  const d = await r.json();
  assert.match(d.title, /Apple iPhone 15 128 GB/i);
});
await t('API: /go affiliate tag ke saath redirect', async () => {
  const d = await (await post('Apple iPhone 15 128 GB')).json();
  const amazon = d.offers.find(o => o.store === 'Amazon.in');
  const r = await fetch(base + amazon.go, { redirect: 'manual' });
  assert.equal(r.status, 302);
  assert.match(r.headers.get('location'), /amazon\.in.*tag=test-21/);
});
await t('API: private link block', async () => {
  for (const u of ['http://127.0.0.1:3000/x', 'http://169.254.169.254/latest/meta-data', 'http://[::1]/a']) {
    const r = await post(u);
    assert.equal(r.status, 400, u);
  }
});
await t('API: kharab input', async () => {
  assert.equal((await post('ab')).status, 400);
  assert.equal((await fetch(base + '/api/lookup', { method: 'POST', body: 'nope' })).status, 400);
  assert.equal((await fetch(base + '/api/product/99999')).status, 404);
});
await t('Static: homepage', async () => {
  const r = await fetch(base + '/');
  assert.equal(r.status, 200);
  assert.match(await r.text(), /Daam Dekho/);
  assert.equal((await fetch(base + '/../server.js')).status, 404);
});

server.close(); fs.rmSync(tmp, { recursive: true, force: true });
console.log(process.exitCode ? `\n${n} pass, baaki FAIL` : `\n${n} tests pass hue`);
setTimeout(() => process.exit(process.exitCode || 0), 100);
