# Daam Dekho

Kisi bhi product ka link (ya naam) daalo. Site us product ka daam alag-alag stores par dikhati hai, ab tak ka sabse sasta rate batati hai, price history ka graph banati hai, aur "Kharido" button se aapke affiliate link ke saath store par bhej deti hai.

## Chalane ke liye (5 minute)

1. **Node.js 22.5 ya naya** install karo (https://nodejs.org). Koi aur package install nahi karna.
2. `.env.example` ko copy karke `.env` naam do.
3. `SERPAPI_KEY` daalo. https://serpapi.com par free account banao (mahine ke kuch searches free). Ye key alag-alag stores ke daam laati hai.
4. `AFFILIATE_AMAZON_TAG` (Amazon Associates ka tag) aur `AFFILIATE_FLIPKART_ID` daalo.
5. Terminal mein:

       npm start

   Phir browser mein http://localhost:3000 kholo.

`SERPAPI_KEY` khali rahe to **DEMO mode** chalta hai (nakli prices), taaki pehle design dekh sako.

## Ye kaise kaam karta hai

1. User link paste karta hai. Server us page ko kholkar product ka naam (aur agar page par likha ho to daam) nikalta hai. Amazon/Flipkart kabhi-kabhi page block kar dete hain, tab naam link ke andar se nikala jaata hai.
2. Naam se SerpApi (Google Shopping) par search hota hai, jo Indian stores ke offers deta hai.
3. Galat results (cover, charger, Pro Max jaisa dusra model) filter hote hain. Har store ka sabse kam daam rakha jaata hai.
4. Har daam database (`data.db`, SQLite) mein din ke hisaab se save hota hai. Yahi price history hai.
5. Har 24 ghante mein purane products ka daam apne aap dobara check hota hai (`REFRESH_HOURS`). History tabhi banti hai jab tak site chalti rahe, isliye jitni jaldi deploy karoge utni jaldi history jama hogi.
6. "Kharido" button `/go/<id>` par jaata hai, jo click ginta hai aur affiliate parameter lagakar store par redirect karta hai.

## Baaki stores ke affiliate links

Amazon aur Flipkart seedhe `.env` se lagte hain. Croma, Myntra, Tata CLiQ jaise stores ke liye `AFFILIATE_RULES` mein domain ke hisaab se rule likho. Aam taur par EarnKaro, Cuelinks ya INRDeals ka tracking link template yahan chalta hai. Udaharan `.env.example` mein hai.

## Deploy

Render, Railway ya kisi bhi VPS par chal jaata hai. `npm start` start command rakho, Environment variables wahin daalo, aur `DB_PATH` ko **persistent disk** par rakho, warna restart par price history mit jayegi. Piche proxy ho to `TRUST_PROXY=1` karo.

## Dhyan rakhne ki baatein

- Amazon aur Flipkart ke pages ko khud scrape karke daam lena unki terms ke khilaaf hai, isliye daam search API se aata hai. Sirf product ka naam nikalne ke liye link ka page ek baar kholte hain.
- SerpApi ke results mein kabhi-kabhi store ka seedha link nahi hota. Aisa link affiliate se nahi judta, wo store ke bhaav ke liye hi kaam aata hai.
- Amazon Associates mein pehle 180 din mein kam se kam 3 sales chahiye warna account band ho sakta hai. Footer ka affiliate disclosure hata mat dena, ye zaroori hai.
- Free SerpApi plan ki limit hai. Isliye ek hi product ka data `CACHE_MINUTES` tak dobara nahi mangwaya jaata, aur har IP ko ek minute mein 15 lookups ki limit hai.

## Tests

    npm test

## Files

- `server.js`: web server, API, database, roz ka price refresh
- `lib.js`: link/title parsing, offer filtering, affiliate links
- `index.html`: website ka front end
- `test.js`: tests
